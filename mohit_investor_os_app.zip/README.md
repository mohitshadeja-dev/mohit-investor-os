# Mohit NIFTY Gann Backtester — MASTER

This is the single source-of-truth build.

## Locked strategy
1. Previous trading day High, Low, Close.
2. Range = High - Low.
3. WMA = Range × 0.382.
4. Resistance = Previous Close + WMA; Support = Previous Close - WMA.
5. On the next session, use 5-minute candles from 09:15 to determine which WMA level is touched first.
6. Put that first-touched level into the 0.125 square-root Gann grid.
7. Buy only when a **1-minute candle closes at/above Buy Above**. Short only when a **1-minute candle closes at/below Sell Below**.
8. A wick/touch alone is not an entry.
9. Only one position may be open at a time.
10. Opposite Gann boundary is stop-loss.
11. Target = 100 NIFTY points from actual confirming close.
12. After an exit, the same levels remain active and a fresh 1-minute close can trigger another trade the same day.
13. No daily trade cap by default.
14. If neither SL nor target hits, exit at final available 1-minute close.
15. If target and SL are both inside the same 1-minute exit candle, use conservative **stop first** by default.

## Zerodha
The backend stores API key, secret, and daily access token encrypted in SQLite. Set `APP_ENCRYPTION_KEY` before starting.

Redirect URL:
`https://YOUR-DOMAIN/api/kite/callback`

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# copy the generated key into APP_ENCRYPTION_KEY
export APP_ENCRYPTION_KEY='...'
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Open `http://localhost:8000`.

## Tests
```bash
pytest -q
```
The tests lock the Gann example, 1-minute close confirmation, and multiple same-day re-entry behavior.
