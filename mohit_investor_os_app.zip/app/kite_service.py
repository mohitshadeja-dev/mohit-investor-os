from __future__ import annotations
import os, time
from datetime import date, datetime, timedelta
import pandas as pd
from kiteconnect import KiteConnect
from .store import get_secret, set_secret

TOKEN_KEY="kite_access_token"

def creds():
    key=get_secret("kite_api_key") or os.getenv("KITE_API_KEY")
    secret=get_secret("kite_api_secret") or os.getenv("KITE_API_SECRET")
    return key,secret

def client(require_token=True):
    key,_=creds()
    if not key: raise RuntimeError("Kite API key is not configured")
    k=KiteConnect(api_key=key)
    tok=get_secret(TOKEN_KEY)
    if tok: k.set_access_token(tok)
    elif require_token: raise RuntimeError("Zerodha is not connected for this session. Complete Kite login.")
    return k

def login_url():
    return client(require_token=False).login_url()

def exchange_request_token(request_token: str):
    key,secret=creds()
    if not key or not secret: raise RuntimeError("Kite API key/secret are not configured")
    k=KiteConnect(api_key=key)
    data=k.generate_session(request_token, api_secret=secret)
    set_secret(TOKEN_KEY,data["access_token"])
    return {"user_id":data.get("user_id"),"login_time":str(data.get("login_time", ""))}

def profile():
    return client().profile()

def fetch_minutes(instrument_token: int, from_date: date, to_date: date) -> pd.DataFrame:
    """Fetch in conservative <=50-day chunks to stay below minute-history request window."""
    k=client()
    chunks=[]
    cur=from_date
    while cur <= to_date:
        end=min(cur+timedelta(days=49),to_date)
        data=k.historical_data(instrument_token, cur, end, "minute", continuous=False, oi=False)
        if data: chunks.extend(data)
        cur=end+timedelta(days=1)
        time.sleep(0.35)
    if not chunks: return pd.DataFrame(columns=["date","open","high","low","close","volume"])
    df=pd.DataFrame(chunks)
    return df.drop_duplicates(subset=["date"]).sort_values("date").reset_index(drop=True)
