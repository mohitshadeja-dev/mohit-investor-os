from __future__ import annotations
import os
from datetime import date
from pathlib import Path
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from dotenv import load_dotenv
load_dotenv()
from .store import set_secret, get_secret, delete_secret
from .kite_service import login_url, exchange_request_token, profile, fetch_minutes
from .strategy import run_backtest

ROOT=Path(__file__).resolve().parent
app=FastAPI(title="Mohit Investor OS — Gann Production API", version="1.0.0")
app.mount("/static",StaticFiles(directory=ROOT/"static"),name="static")

class KiteSettings(BaseModel):
    api_key: str = Field(min_length=3)
    api_secret: str = Field(min_length=3)

class BacktestRequest(BaseModel):
    from_date: date
    to_date: date
    instrument_token: int = int(os.getenv("NIFTY_INSTRUMENT_TOKEN","256265"))
    wma_factor: float = 0.382
    target_points: float = 100.0
    gann_step: float = 0.125
    reentry: bool = True
    max_trades_per_day: int | None = None
    same_bar_policy: str = "stop_first"

@app.get("/")
def home(): return FileResponse(ROOT/"static"/"index.html")

@app.get("/health")
def health(): return {"ok":True,"service":"mohit-gann-prod"}

@app.get("/api/kite/status")
def status():
    configured=bool(get_secret("kite_api_key") or os.getenv("KITE_API_KEY"))
    try:
        p=profile(); return {"configured":configured,"connected":True,"user_id":p.get("user_id"),"user_name":p.get("user_name")}
    except Exception as e:
        return {"configured":configured,"connected":False,"detail":str(e)}

@app.post("/api/kite/settings")
def save_settings(s: KiteSettings):
    set_secret("kite_api_key",s.api_key.strip()); set_secret("kite_api_secret",s.api_secret.strip())
    delete_secret("kite_access_token")
    return {"saved":True}

@app.get("/api/kite/login-url")
def get_login_url():
    try: return {"url":login_url()}
    except Exception as e: raise HTTPException(400,str(e))

@app.get("/api/kite/callback")
def callback(request_token: str = Query(...)):
    try: exchange_request_token(request_token)
    except Exception as e: raise HTTPException(400,str(e))
    return RedirectResponse(url="/?connected=1")

@app.post("/api/backtest")
def backtest(req: BacktestRequest):
    if req.from_date >= req.to_date: raise HTTPException(400,"from_date must be before to_date")
    try:
        df=fetch_minutes(req.instrument_token,req.from_date,req.to_date)
        if df.empty: raise RuntimeError("No minute candles returned by Kite for that range/token")
        summary,trades=run_backtest(df, req.wma_factor, req.target_points, req.gann_step, req.reentry, req.max_trades_per_day, req.same_bar_policy)
        return {"source":"Zerodha Kite historical minute data","instrument_token":req.instrument_token,
                "from_date":str(req.from_date),"to_date":str(req.to_date),"candles":len(df),"summary":summary,"trades":trades}
    except Exception as e: raise HTTPException(400,str(e))
