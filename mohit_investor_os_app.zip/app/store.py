from __future__ import annotations
import json, os, sqlite3
from pathlib import Path
from cryptography.fernet import Fernet

DB = Path(os.getenv("APP_DB_PATH", "./mohit_os.db"))

def _conn():
    c=sqlite3.connect(DB)
    c.execute("CREATE TABLE IF NOT EXISTS secrets (k TEXT PRIMARY KEY, v BLOB NOT NULL)")
    return c

def _fernet():
    key=os.getenv("APP_ENCRYPTION_KEY","").strip()
    if not key:
        raise RuntimeError("APP_ENCRYPTION_KEY is not configured")
    return Fernet(key.encode())

def set_secret(k: str, value: str):
    token=_fernet().encrypt(value.encode())
    with _conn() as c:
        c.execute("INSERT INTO secrets(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v",(k,token))

def get_secret(k: str):
    with _conn() as c:
        row=c.execute("SELECT v FROM secrets WHERE k=?",(k,)).fetchone()
    if not row: return None
    return _fernet().decrypt(row[0]).decode()

def delete_secret(k: str):
    with _conn() as c: c.execute("DELETE FROM secrets WHERE k=?",(k,))
