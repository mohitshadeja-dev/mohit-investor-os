from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import time
from math import floor, sqrt
from typing import Optional
import pandas as pd

IST = "Asia/Kolkata"

@dataclass
class Trade:
    date: str
    trade_no: int
    first_touch: str
    touch_time: str
    reference_price: float
    buy_above: float
    sell_below: float
    side: str
    entry_time: str
    entry: float
    stop: float
    target: float
    exit_time: str
    exit: float
    reason: str
    points: float

    def dict(self):
        return asdict(self)


def _norm(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d.columns = [str(c).lower() for c in d.columns]
    if "date" not in d.columns:
        raise ValueError("Minute data requires a date column")
    d["date"] = pd.to_datetime(d["date"], errors="coerce")
    if d["date"].dt.tz is None:
        d["date"] = d["date"].dt.tz_localize(IST)
    else:
        d["date"] = d["date"].dt.tz_convert(IST)
    for c in ("open","high","low","close"):
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d = d.dropna(subset=["date","open","high","low","close"]).sort_values("date")
    # NSE regular market only.
    local_t = d["date"].dt.time
    d = d[(local_t >= time(9,15)) & (local_t <= time(15,30))].reset_index(drop=True)
    return d


def gann_levels(price: float, step: float = 0.125) -> tuple[float,float]:
    """Earlier Mohit OS grid: nearest 0.125 square-root boundaries around the reference price."""
    r = sqrt(float(price))
    n = floor((r + 1e-10) / step)
    sell = round((n * step) ** 2, 2)
    buy = round(((n + 1) * step) ** 2, 2)
    return buy, sell


def _daily_hlc(day: pd.DataFrame) -> tuple[float,float,float]:
    return float(day.high.max()), float(day.low.min()), float(day.iloc[-1].close)


def _first_touch_5m(day: pd.DataFrame, resistance: float, support: float):
    x = day.set_index("date")
    # Anchored to exchange clock; candles 09:15, 09:20, ...
    five = x.resample("5min", origin="start_day", offset="15min").agg(
        open=("open","first"), high=("high","max"), low=("low","min"), close=("close","last")
    ).dropna()
    for ts, b in five.iterrows():
        tr = float(b.high) >= resistance
        tsup = float(b.low) <= support
        if tr and tsup:
            return {"ambiguous": True, "time": ts}
        if tr or tsup:
            level = resistance if tr else support
            side = "RESISTANCE" if tr else "SUPPORT"
            end = ts + pd.Timedelta(minutes=4, seconds=59)
            mins = day[(day.date >= ts) & (day.date <= end)]
            cond = mins.high >= level if tr else mins.low <= level
            m = mins[cond]
            touch_time = m.iloc[0].date if len(m) else ts
            return {"ambiguous": False, "type": side, "level": float(level), "time": touch_time}
    return None


def run_backtest(
    minute_df: pd.DataFrame,
    wma_factor: float = 0.382,
    target_points: float = 100.0,
    gann_step: float = 0.125,
    reentry: bool = True,
    max_trades_per_day: Optional[int] = None,
    same_bar_policy: str = "stop_first",
):
    """
    Rules:
    - Previous trading day's H/L/C -> WMA support/resistance.
    - Next day, whichever WMA level is first touched on 5-minute bars is the reference.
    - Gann boundaries from 0.125 square-root grid.
    - Entry only after 1-minute CLOSE >= buy or <= sell.
    - Entry price is confirming 1-minute close.
    - Target is +/- target_points from entry; opposite Gann boundary is SL.
    - Re-entry is allowed after a completed trade when reentry=True.
    - If SL and target both occur within same minute after entry, conservative stop_first by default.
    """
    d = _norm(minute_df)
    d["session"] = d.date.dt.date
    sessions = [(k, v.drop(columns="session").reset_index(drop=True)) for k,v in d.groupby("session", sort=True)]
    trades: list[Trade] = []
    stats = {"test_days": max(0,len(sessions)-1), "no_touch":0, "touch_ambiguous":0, "no_trigger":0, "same_bar_both":0}

    for di in range(1, len(sessions)):
        session_date, day = sessions[di]
        _, prev = sessions[di-1]
        ph, pl, pc = _daily_hlc(prev)
        wma = (ph-pl) * wma_factor
        resistance, support = pc+wma, pc-wma
        touch = _first_touch_5m(day, resistance, support)
        if touch is None:
            stats["no_touch"] += 1
            continue
        if touch.get("ambiguous"):
            stats["touch_ambiguous"] += 1
            continue
        ref = touch["level"]
        buy, sell = gann_levels(ref, gann_step)
        cursor = int(day.index[day.date >= touch["time"]][0]) if any(day.date >= touch["time"]) else 0
        ntrade = 0
        day_had_trigger = False

        while cursor < len(day):
            if max_trades_per_day is not None and ntrade >= max_trades_per_day:
                break
            entry_i = None; side = None
            for i in range(cursor, len(day)):
                c = float(day.iloc[i].close)
                # If both are somehow true due malformed overlapping levels, skip.
                if c >= buy:
                    entry_i, side = i, "LONG"; break
                if c <= sell:
                    entry_i, side = i, "SHORT"; break
            if entry_i is None:
                if not day_had_trigger: stats["no_trigger"] += 1
                break
            day_had_trigger = True
            eb = day.iloc[entry_i]
            entry = float(eb.close)
            stop = sell if side == "LONG" else buy
            target = entry + target_points if side == "LONG" else entry - target_points
            exit_i = len(day)-1; exit_px = float(day.iloc[-1].close); reason = "EOD"

            for j in range(entry_i+1, len(day)):
                b = day.iloc[j]
                hit_sl = float(b.low) <= stop if side == "LONG" else float(b.high) >= stop
                hit_t = float(b.high) >= target if side == "LONG" else float(b.low) <= target
                if hit_sl and hit_t:
                    stats["same_bar_both"] += 1
                    if same_bar_policy == "exclude":
                        reason = "AMBIGUOUS"; exit_px = float("nan"); exit_i = j
                    else:
                        reason = "SL"; exit_px = stop; exit_i = j
                    break
                if hit_sl:
                    reason = "SL"; exit_px = stop; exit_i = j; break
                if hit_t:
                    reason = "TARGET"; exit_px = target; exit_i = j; break

            if reason != "AMBIGUOUS":
                pts = exit_px-entry if side == "LONG" else entry-exit_px
                ntrade += 1
                trades.append(Trade(
                    date=str(session_date), trade_no=ntrade, first_touch=touch["type"],
                    touch_time=str(touch["time"]), reference_price=round(ref,2),
                    buy_above=buy, sell_below=sell, side=side,
                    entry_time=str(eb.date), entry=round(entry,2), stop=stop, target=round(target,2),
                    exit_time=str(day.iloc[exit_i].date), exit=round(exit_px,2), reason=reason, points=round(pts,2)
                ))
            if not reentry or reason == "EOD":
                break
            cursor = exit_i + 1

    points = [t.points for t in trades]
    wins = sum(p > 0 for p in points)
    losses = sum(p < 0 for p in points)
    total = round(sum(points),2)
    eq=peak=0.0; maxdd=0.0; streak=cur=0
    for p in points:
        eq += p; peak=max(peak,eq); maxdd=max(maxdd,peak-eq)
        if p < 0: cur += 1; streak=max(streak,cur)
        else: cur=0
    summary = {
        **stats,
        "trades": len(trades), "wins": wins, "losses": losses,
        "win_rate": round(100*wins/len(trades),2) if trades else 0,
        "total_points": total,
        "avg_points": round(total/len(trades),2) if trades else 0,
        "targets": sum(t.reason=="TARGET" for t in trades),
        "stops": sum(t.reason=="SL" for t in trades),
        "eod": sum(t.reason=="EOD" for t in trades),
        "max_drawdown_points": round(maxdd,2),
        "max_losing_streak": streak,
    }
    return summary, [t.dict() for t in trades]
