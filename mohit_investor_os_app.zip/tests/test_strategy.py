import pandas as pd
from app.strategy import gann_levels, run_backtest

IST = "Asia/Kolkata"

def bar(ts, o, h, l, c):
    return {"date": pd.Timestamp(ts, tz=IST), "open": o, "high": h, "low": l, "close": c, "volume": 0}

def test_gann_exact_published_example():
    buy, sell = gann_levels(11941.70)
    assert buy == 11962.89
    assert sell == 11935.56

def test_entry_requires_one_minute_close_not_wick():
    rows = []
    # Previous day: H=10100, L=9900, C=10000 => Resistance=10076.4
    rows += [
        bar("2026-09-10 09:15", 10000, 10100, 9900, 10000),
        bar("2026-09-10 15:30", 10000, 10000, 10000, 10000),
    ]
    # 09:15 wick crosses Buy Above 10100.25, but close does NOT. 09:16 close confirms.
    rows += [
        bar("2026-09-11 09:15", 10070, 10105, 10060, 10090),
        bar("2026-09-11 09:16", 10090, 10103, 10088, 10101),
        bar("2026-09-11 15:30", 10101, 10102, 10100, 10101),
    ]
    s, trades = run_backtest(pd.DataFrame(rows), reentry=False)
    assert s["trades"] == 1
    assert trades[0]["entry_time"].startswith("2026-09-11 09:16")
    assert trades[0]["entry"] == 10101.0

def test_multiple_same_day_reentries_after_stop_and_target():
    rows = []
    rows += [
        bar("2026-09-10 09:15", 10000, 10100, 9900, 10000),
        bar("2026-09-10 15:30", 10000, 10000, 10000, 10000),
    ]
    rows += [
        # First touch is resistance; close below buy trigger.
        bar("2026-09-11 09:15", 10070, 10080, 10060, 10075),
        # Trade 1 long confirms on close.
        bar("2026-09-11 09:16", 10075, 10103, 10074, 10101),
        # Trade 1 SL at opposite Gann level 10075.14.
        bar("2026-09-11 09:17", 10100, 10101, 10070, 10080),
        # Trade 2 re-enters long after a fresh 1m close above same buy level.
        bar("2026-09-11 09:18", 10080, 10104, 10079, 10102),
        # Trade 2 reaches its 100-point target 10202.
        bar("2026-09-11 09:19", 10102, 10205, 10100, 10203),
        bar("2026-09-11 15:30", 10203, 10204, 10202, 10203),
    ]
    s, trades = run_backtest(pd.DataFrame(rows), reentry=True, max_trades_per_day=2)
    assert s["trades"] == 2
    assert [t["trade_no"] for t in trades] == [1, 2]
    assert trades[0]["reason"] == "SL"
    assert trades[1]["reason"] == "TARGET"
    assert trades[1]["entry_time"].startswith("2026-09-11 09:18")

def test_one_trade_only_when_reentry_disabled():
    rows = []
    rows += [
        bar("2026-09-10 09:15", 10000, 10100, 9900, 10000),
        bar("2026-09-10 15:30", 10000, 10000, 10000, 10000),
    ]
    rows += [
        bar("2026-09-11 09:15", 10070, 10080, 10060, 10075),
        bar("2026-09-11 09:16", 10075, 10103, 10074, 10101),
        bar("2026-09-11 09:17", 10100, 10101, 10070, 10080),
        bar("2026-09-11 09:18", 10080, 10104, 10079, 10102),
        bar("2026-09-11 09:19", 10102, 10205, 10100, 10203),
        bar("2026-09-11 15:30", 10203, 10204, 10202, 10203),
    ]
    s, trades = run_backtest(pd.DataFrame(rows), reentry=False)
    assert s["trades"] == 1
    assert len(trades) == 1
